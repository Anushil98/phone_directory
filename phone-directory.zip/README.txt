A Pen created at CodePen.io. You can find this one at https://codepen.io/Anushil98/pen/YgYomE.

 This is a website to store phone numbers alongside names.
the data is stored in the local storage.